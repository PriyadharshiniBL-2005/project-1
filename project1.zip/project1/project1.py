# import cv2
# import numpy as np

# # Define the color ranges in HSV
# color_ranges = {
#     'Red': [(0, 120, 70), (10, 255, 255)],  # Lower and upper bounds for red
#     'Yellow': [(15, 150, 150), (35, 255, 255)],  # Lower and upper bounds for yellow
#     'Green': [(36, 100, 100), (86, 255, 255)]  # Lower and upper bounds for green
# }

# # Load the image
# image = cv2.imread('trafficsign.jpg')

# # Convert the image to HSV
# hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

# # Initialize a dictionary to store the detected colors
# detected_colors = {}

# # Iterate over the color ranges
# for color, (lower, upper) in color_ranges.items():
#     # Create a mask for the current color
#     lower_bound = np.array(lower, dtype=np.uint8)
#     upper_bound = np.array(upper, dtype=np.uint8)
#     mask = cv2.inRange(hsv_image, lower_bound, upper_bound)
    
#     # Count the number of non-zero pixels in the mask
#     color_pixels = cv2.countNonZero(mask)
    
#     # If the number of pixels exceeds a threshold, consider it detected
#     if color_pixels > 1000:  # Adjust the threshold as needed
#         detected_colors[color] = color_pixels

# # Determine the most prominent color
# if detected_colors:
#     # Sort the detected colors by the number of pixels in descending order
#     sorted_colors = sorted(detected_colors.items(), key=lambda x: x[1], reverse=True)
#     most_prominent_color = sorted_colors[0][0]
#     print(f"Detected Traffic Light Color: {most_prominent_color}")
# else:
#     print("No traffic light detected.")

# # Annotate the image with the detected color
# font = cv2.FONT_HERSHEY_SIMPLEX
# cv2.putText(image, most_prominent_color, (50, 50), font, 1, (0, 255, 0), 2, cv2.LINE_AA)

# # Show the image
# cv2.imshow('Traffic Light Detection', image)
# cv2.waitKey(0)
# cv2.destroyAllWindows()


# import cv2
# import numpy as np

# # Define the color ranges in HSV
# color_ranges = {
#     'Red': [(0, 120, 70), (10, 255, 255)],  # Lower and upper bounds for red
#     'Yellow': [(15, 150, 150), (35, 255, 255)],  # Lower and upper bounds for yellow
#     'Green': [(36, 100, 100), (86, 255, 255)]  # Lower and upper bounds for green
# }

# # Load the image
# image = cv2.imread('trafficsign.jpg')

# # Convert the image to HSV
# hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

# # Manually select the ROI
# roi = cv2.selectROI("Select ROI", image)
# cv2.destroyAllWindows()

# # Crop the image to the selected ROI
# x, y, w, h = roi
# roi_image = hsv_image[y:y+h, x:x+w]

# # Initialize a dictionary to store the detected colors
# detected_colors = {}

# # Iterate over the color ranges
# for color, (lower, upper) in color_ranges.items():
#     # Create a mask for the current color
#     lower_bound = np.array(lower, dtype=np.uint8)
#     upper_bound = np.array(upper, dtype=np.uint8)
#     mask = cv2.inRange(roi_image, lower_bound, upper_bound)
    
#     # Count the number of non-zero pixels in the mask
#     color_pixels = cv2.countNonZero(mask)
    
#     # If the number of pixels exceeds a threshold, consider it detected
#     if color_pixels > 1000:  # Adjust the threshold as needed
#         detected_colors[color] = color_pixels

# # Determine the most prominent color
# if detected_colors:
#     # Sort the detected colors by the number of pixels in descending order
#     sorted_colors = sorted(detected_colors.items(), key=lambda x: x[1], reverse=True)
#     most_prominent_color = sorted_colors[0][0]
#     print(f"Detected Traffic Light Color: {most_prominent_color}")
# else:
#     print("No traffic light detected.")

# # Annotate the image with the detected color
# font = cv2.FONT_HERSHEY_SIMPLEX
# cv2.putText(image, most_prominent_color, (x, y - 10), font, 1, (0, 255, 0), 2, cv2.LINE_AA)

# # Draw the ROI rectangle
# cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)

# # Show the image
# cv2.imshow('Traffic Light Detection', image)
# cv2.waitKey(0)
# cv2.destroyAllWindows()

import cv2
import numpy as np

# Load the image
image = cv2.imread("trafficsign.jpg")
hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

# Define color ranges in HSV
color_ranges = {
    "Red": [(np.array([0, 120, 70]), np.array([10, 255, 255])),  # Lower red
            (np.array([170, 120, 70]), np.array([180, 255, 255]))],  # Upper red
    "Yellow": [(np.array([20, 100, 100]), np.array([30, 255, 255]))],
    "Green": [(np.array([40, 50, 50]), np.array([90, 255, 255]))]
}

# Function to detect and draw bounding boxes
def detect_color(color_name, masks):
    for mask in masks:
        result = cv2.bitwise_and(image, image, mask=cv2.inRange(hsv, mask[0], mask[1]))
        gray = cv2.cvtColor(result, cv2.COLOR_BGR2GRAY)
        contours, _ = cv2.findContours(gray, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area > 100:  # Filter small noise
                x, y, w, h = cv2.boundingRect(cnt)
                cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)
                cv2.putText(image, color_name, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX,
                            0.5, (0, 255, 0), 2)

# Run detection
for color, ranges in color_ranges.items():
    detect_color(color, ranges)

# Show the result
cv2.imshow("Detected Traffic Lights", image)
cv2.waitKey(0)
cv2.destroyAllWindows()
